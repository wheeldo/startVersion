<?php

$res=array();
header('Content-Type:application/json');
$allowed_ext=array();
$allowed_ext[]="csv";

if ($_FILES["csv"]["error"] > 0){
    echo "Return Code: " . $_FILES["csv"]["error"] . "<br>";
}
else {
    $ex=explode(".",$_FILES["csv"]["name"]);
    $ext=strtolower($ex[(count($ex)-1)]);
    /////////// security checks: ///////////////////
    // check no 1:
    if(!in_array($ext, $allowed_ext)) {
        $res['status']="faild";
        $res['error']="Your file is not a csv file!";
        echo json_encode($res);
        die();
    }
        
    
    if(($handle = fopen($_FILES['csv']['tmp_name'], 'r')) !== FALSE) {
        $result=array();
        // necessary if a large csv file
        set_time_limit(5);

        $row = 0;

        while(($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
            // number of fields in the csv
            $num = count($data);

            for($i=0;$i<$num;$i++):
                $result[$i][]=utf8_encode($data[$i]);
            endfor;

            $row++;
        }
        fclose($handle);

        
        $ds=DIRECTORY_SEPARATOR;
        $base_path=dirname(__FILE__);
        $file_location=$base_path.$ds."..".$ds."uploads".$ds."csv".$ds.$_POST['res_mark'].".txt";
        //unlink($file_location);
        file_put_contents($file_location, utf8_encode(json_encode($result, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE))); 
        $res['status']="ok";
        $res['data']=$result;
        echo json_encode($res);
        die();
    }
}