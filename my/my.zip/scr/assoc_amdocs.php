<?php
require_once('../modules/modules.php');
require_once('../checkLogin.php');

if(!empty($_POST)) {
    var_dump($_POST);
    die();
    
    $ans=$dbop->selectDB("users","WHERE `userOrganizationID`='17' AND `userID`>227262 AND `userID`<228285");
    for($i=0;$i<$ans['n'];$i++) {
        $row=mysql_fetch_assoc($ans['p']);
         echo $i.")".$row['userName']."<br>";   

         $fields=array();
         $fields['teamUserUserID']=$row['userID'];
         $fields['teamUserTeamID']=648;
         $dbop->insertDB("teamsUsers",$fields,false);
    }
}
?>
<form action="" method="post">
    
    
    
</form>