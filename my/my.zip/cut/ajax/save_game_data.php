<?php

sleep(3);