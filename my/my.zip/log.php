<?php
require_once('modules/modules.php');
require_once('checkLogin.php');
header("location:/");

