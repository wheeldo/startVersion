var addPlayerCtrl = function ($scope, $modalInstance, f_data) {

    $scope.player={
        name:"",
        email:""
    }

    $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
    };
    
    $scope.addPlayer = function() {
        if($scope.player.name && $scope.player.email) {
            $modalInstance.close($scope.player);
        }
        else {
            alert("Please fill all the fileds!");
        }

    };
};